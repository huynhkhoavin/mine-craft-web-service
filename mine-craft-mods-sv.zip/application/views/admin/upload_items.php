

<style>
    .center {
        margin: auto;
        width: 60%;
        padding: 50px;
        
    }
</style>
<body>

    <div class="center" >
        <div class="form-group">

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="sel1">Item Type</label>
                <select class="form-control" id="sel1">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select>
            </div>
            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Item Name</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>
            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Author</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Version</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Size</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="sel1">Category</label>
                <select class="form-control" id="sel1">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select>
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Short Description</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Long Description</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 30px">
                <label for="inputdefault">Image Url</label>
                <input class="form-control"  id="inputdefault" type="text">
                <button type="button" style="float:right;" class="btn btn-default">Browse</button>
            </div>
            <!--==-->
            <div style="margin-bottom: 30px">
                <label for="inputdefault">File Url</label>
                <input class="form-control"  id="inputdefault" type="text">
                <button type="button" style="float:right;" class="btn btn-default">Browse</button>
            </div>
            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Video Code</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>

            <!--==-->
            <div style="margin-bottom: 15px">
                <label for="inputdefault">Priority</label>
                <input class="form-control" id="inputdefault" type="text">
            </div>
            
            <!--==-->
            <div style="margin-bottom: 15px">
                <button type="button" class="btn btn-default">Upload</button>
            </div>
            
        </div>
    </div>
    </body>